function init() {
    if ((window.parent) && (window.parent != window)){
        API = FindAPI(window.parent);
    } 
    if ((API == null) && (window.opener != null)){
        API = FindAPI(window.opener); 
    } 
    if (API == null) { 
        alert("No API adapter found"); 
    } 
    else { 
        API.LMSInitialize(""); 
    } 
}

function finish() {
    localStorage.clear(); 
    if (API != null) { 
        API.LMSSetValue("cmi.core.lesson_status","completed");
        API.LMSSetValue("cmi.core.score.max",);
        API.LMSSetValue("cmi.core.score.min",0);
        API.LMSSetValue("cmi.core.score.raw", solucion_sel);
        API.LMSFinish(""); 
    } 
}

function finalizarActividad()
{
    init();
    finish();
    parent.window.location = "https://moodle.upm.es/titulaciones/oficiales/mod/scorm/view.php?id=552608";
}

function llenarTablaConArray(array) {
            
    // Obtener la tabla y su cuerpo
    var tabla = document.getElementById("tablaFinal");
    var cuerpoTabla = tabla.getElementsByTagName("tbody")[0];

    // Limpiar el contenido previo de la tabla
    cuerpoTabla.innerHTML = "";

    // Recorrer el array y añadir una fila por cada elemento
    for (var i = 0; i < array.length; i++) {
        // Crear una nueva fila
        var fila = cuerpoTabla.insertRow();

        // Añadir las celdas con los valores del elemento
        var celda1 = fila.insertCell();
        var celda2 = fila.insertCell();
        var celda3 = fila.insertCell();

        celda1.innerHTML = array[i];
        celda2.innerHTML = "Valor 2";
        celda3.innerHTML = "Valor 3";
    }
}